import estdat.lineal.*;

public class Persona{
    private String nombre;
    private int edad;
    private int nroCelular;
    private Lista<Persona> contactos;
    private Lista<Mensaje> recibidos, enviados;
    public Persona(String nombre, int edad, int nroCelular){
        nombre = nombre.toLowerCase();
        this.nombre = nombre;
        this.edad = edad;
        this.nroCelular = nroCelular;
        contactos = new ListaSE<Persona>();
        recibidos = new ListaSE<Mensaje>();
        enviados = new ListaSE<Mensaje>();
    }
    
    private Lista<Mensaje> getRecibidos(){
        return recibidos;
    }
    
    private String getNombre(){
        return nombre;
    }
    
    private int getCelular(){
        return nroCelular;
    }
    
    private boolean esVacia(){
        return contactos == null;
    }
    
    public void agregarAmigo(Persona amige){
        contactos.insertar(amige);
    }
    
    public Persona buscarAmigoXCelular(int nroCelular){
        Persona amige = null;
        if(!esVacia())
            amige = buscar(contactos.longitud()-1, nroCelular);
        
        return amige;
    }
    
    private Persona buscar(int pos, int numero){
        Persona p = null;
        if(pos>-1){
            p = contactos.acceder(pos);
            if(p.getCelular() == numero){
                p = p;
            }else{
                p = buscar(pos-1,numero);
            }
        }
        return p;
    }
    
    public Persona buscarAmigoXNombre(String nombre){
        Persona amige = null;
        nombre = nombre.toLowerCase();
        if(!esVacia())
            amige = buscar(contactos.longitud()-1, nombre);
        
        return amige;
    }
    
    private Persona buscar(int pos, String nombre){
        Persona p = null;
        if(pos>-1){
            p = contactos.acceder(pos);
            if(p.getNombre().equals(nombre)){
                p = p;
            }else{
                p = buscar(pos-1,nombre);
            }
        }
        return p;
    }
    
    public void sendMensaje(int celular, String mensaje){
        Mensaje sms = new Mensaje(nroCelular, celular, mensaje);
        Persona amige = buscarAmigoXCelular(celular);
        if(amige != null){
            enviados.insertar(sms);
            amige.recibidos.insertar(sms);
        }
    }
    
    public void bandejaRecibidos(){
        int tam = recibidos.longitud()-1;
        for(int i = tam; i>-1; i--){
            Mensaje sms = recibidos.acceder(i);
            sms.cambiar();
        }
    }
    
    public void bandejaRecibidoEspecifico(int celular){
        int tam = recibidos.longitud()-1;
        for(int i = tam; i>-1; i--){
            Mensaje sms = recibidos.acceder(i);
            if(sms.getRemitente() == celular)
                sms.cambiar();
                
        }
    }
    
    public Lista<Mensaje> enviado(){
        return enviados;
    }
    
    public Lista<Mensaje> enviadoEspecifico(int celular){
        Persona per = buscarAmigoXCelular(celular);
        Lista<Mensaje> send = per.getRecibidos();
        Lista<Mensaje> listasms = new ListaSE<Mensaje>();
        int tam = send.longitud();
        
        for(int i = 0; i<tam;i++){
            Mensaje sms = send.acceder(i);
            if(sms.getRemitente()==nroCelular){
                listasms.insertar(sms);
            }
        }
        
        return listasms;
    }
}
