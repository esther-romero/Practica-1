

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import estdat.lineal.ListaSE;
import estdat.nolineal.*;
/**
 * The test class SumaArbolTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SumaArbolTest
{
    /**
     * Default constructor for test class SumaArbolTest
     */
    public SumaArbolTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testSumar(){
        ListaSE<Integer> ruta = new ListaSE<Integer>();
        ArbolBin<Integer> arb = new ArbolBin<Integer>();
        SumaArbol a = new SumaArbol(); 
        arb.insertar(4);
        arb.insertar(2);
        arb.insertar(5);
        ruta.insertar(4);
        ruta.insertar(5);
        arb.insertar(5, ruta);
        assertEquals(63, a.suma(arb));
    }
}
