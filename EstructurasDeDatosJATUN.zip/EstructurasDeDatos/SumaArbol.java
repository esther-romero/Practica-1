import estdat.nolineal.*;
import estdat.lineal.*;

public class SumaArbol
{
    public int suma(ArbolBin<Integer> arb){
        int nivel = arb.altura()-1;
        Lista<Integer> par = new ListaSE<Integer>();
        Lista<Integer> imp = new ListaSE<Integer>();
        for(int i = nivel; i>-1; i--){
            if(i%2 == 0){
                par.insertarTodos(arb.datosNivel(i));
            }else{
                imp.insertarTodos(arb.datosNivel(i));
            }
        }
        int parS = suma(par);
        int impS = suma(imp);
        return parS * impS;
    }
    
    private int suma(Lista<Integer> lista){
        int res;
        if(lista.esVacia()){
            res = 0;
        }else{
            res = lista.eliminar(0) + suma(lista);
        }
        return res;
    }
}
    