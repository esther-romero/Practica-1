package estdat.lineal;


public class ListaDE<T extends Comparable<T>> implements Lista<T> 
{
    private NodoDE<T> ini;
    
    public ListaDE(){
        ini = null;
    }
    
    public boolean esVacia(){
        return ini == null;
    }
    
    public void insertar(T dato){
        NodoDE<T> p = new NodoDE<T>(dato);
        if(esVacia()){
            ini = p;
            ini.setAnt(null);
            ini.setSuc(null);
        }else{
            insertar(ini, dato);
        }
    }
    
    private void insertar(NodoDE<T> p, T dato){
        NodoDE<T> q = new NodoDE<T>(dato);
        if(p.getSuc() == null){
            p.setSuc(q);
            q.setAnt(p);
            q.setSuc(null);
        }else{
            insertar(p.getSuc(), dato);
        }
    }
    
    public T eliminar(int pos){
        T datoElim = null;
        NodoDE<T> q,s,r;
        if(!esVacia()){
            q = buscarPos(ini,pos);
            if(q != null){
                datoElim = q.getDato();
                s = q.getSuc();
                r = q.getAnt();
                if(longitud() > 1){
                    if(s != null && r != null){
                        r.setSuc(s);
                        s.setAnt(r);
                    }else{
                        if(r == null){
                            s.setAnt(null);
                            ini = s;
                        }else{
                            if(s == null){
                                r.setSuc(null);
                            }
                        }
                    }
                }else{
                    ini = null;
                }
            }
        }
        return datoElim;
    }
    
    private NodoDE<T> buscarPos(NodoDE<T> q, int pos){
        NodoDE<T> elNodo;
        if(pos == 0){
            elNodo = q;
        }else{
            elNodo = buscarPos(q.getSuc(), pos-1);
        }
        return elNodo;
    }
    
    public T acceder(int pos){
        NodoDE<T> q;
        T elDato = null;
        if(!esVacia()){
            if(pos < longitud()){
                q = buscarPos(ini, pos);
                elDato = q.getDato();
            }
        }
        return elDato;
    }
    
    public void reemplazar(int pos,T dato){
        NodoDE<T> q;
        if(!esVacia() && pos < longitud()){
            q = buscarPos(ini,pos);
            q.setDato(dato);
        }
    }
    
    public void insertar(int pos, T dato){
        NodoDE<T> p,q,r;
        p = new NodoDE<T>(dato);
        if(esVacia()){
            if(pos == 0){
                ini = p;
                ini.setSuc(null);
                ini.setAnt(null);
            }
        }else{
            if(pos <= longitud()){
                q = buscarPos(ini,pos);
                if(q != null){
                    r = q.getAnt();
                    if(pos == 0){
                        ini = p;
                        ini.setAnt(null);
                        ini.setSuc(q);
                        q.setAnt(ini);
                    }else{
                        q.setAnt(p);
                        r.setSuc(p);
                        p.setSuc(q);
                        p.setAnt(r);
                    }
                }
                else{
                    q = buscarPos(ini,longitud()-1);
                    q.setSuc(p);
                    p.setAnt(q);
                    p.setSuc(null);
                }
            }
        }
    }
    
    public int longitud(){
        int longitud;
        if(esVacia()){
            longitud = 0;
        }else{
            longitud = contar(ini);
        }
        return longitud;
    }
    
    private int contar(NodoDE<T> q){
        int contador;
        if(q.getSuc() == null){
            contador = 1;
        }else{
            contador = 1+contar(q.getSuc());
        }
        return contador;
    }
    
    public boolean buscar(T dato){
        boolean existe = false;
        if(!esVacia()){
            existe = buscar(longitud()-1, dato);
        }
        return existe;
    }
    
    private boolean buscar(int pos, T dato){
        boolean existe = false;
        NodoDE<T> q;
        if(pos >= 0){
            q = buscarPos(ini, pos);
            if(q.getDato().equals(dato)){
                existe = true;
            }else{
                existe = buscar(pos-1, dato);
            }
        }
        return existe;
    }
    
    public void vaciar(){
        if(!esVacia()){
            ini = null;
        }
    }
    
    public int indiceDe(T dato){
        int res =  -1;
        if(!esVacia()){
            res = indiceDe(longitud()-1, dato);
        }
        return res;
    }
    
    private int indiceDe(int pos, T dato){
        int iesima = -1;
        NodoDE<T> q;
        if(pos >= 0){
            q = buscarPos(ini, pos);
            if(q.getDato().equals(dato)){
                iesima = pos;
            }else{
                iesima = indiceDe(pos-1, dato);
            }
        }
        return iesima;
    }
    
    public String toString(){
        String datos;
        if(esVacia())
            datos = "{}";
        else
            datos = "{" + toString(ini) + "}";
        return datos;
    }
    
    private String toString(NodoDE<T> q){
        String datos;
        if(q.getSuc() == null)
            datos = q.getDato() + "";
        else
            datos = q.getDato() + ", " + toString(q.getSuc());
        return datos;
    }
    
    public T eliminar(T dato){
        T res = null;
        int dt = indiceDe(dato);
        if(dt != -1){
            res = eliminar(dt);
        }
        return res;
    }
   
    public boolean equals(Lista<T> lista){
        boolean igual;
        if(esVacia())
            igual = lista.esVacia();
        else
            igual = equals(lista, 0, lista.longitud(), ini);
        return igual;
    }
    
    private boolean equals(Lista<T> lista, int i, int tam, NodoDE<T> q){
        boolean igual;
        if(i < tam){
            if(q.getSuc() == null)
                igual = lista.acceder(i).equals(q.getDato()) && !(i+1 < tam);
            else
                igual = lista.acceder(i).equals(q.getDato()) && 
                equals(lista, i+1, tam, q.getSuc());
        }else{
            igual = false;
        }
        return igual;
    }
    
    public void invertir(){
        if(longitud()>1){
            T dato = eliminar(0);
            invertir();
            insertar(dato);
        }
    }
    
    // public void invertir(){
        // NodoDE<T> ult;
        // if(!esVacia()){
            // ult = buscarPos(ini, longitud()-1);
            // invertir(ini);
            // ini = ult;
        // }
    // }
    
    // private void invertir(NodoDE<T> q){
        // NodoDE<T> r,s;
        // r = q.getAnt();
        // s = q.getSuc();
        // if(q.getSuc() == null){
            // q.setSuc(r);
            // q.setAnt(s);
        // }else{
            // q.setSuc(r);
            // q.setAnt(s);
            // invertir(s);
        // }
    // }
    
    public void insertarTodos(Lista<T> lista){
        insertarTodos(lista, 0, lista.longitud());
    }
    
    private void insertarTodos(Lista<T> lista, int i, int tam){
        if(i < tam){
            insertar(lista.acceder(i));
            insertarTodos(lista, i+1, tam);
        }   
    }
    
    public Iterador<T> obtenerIterador(){
        return new IteradorDE<T>(ini);
    }
    
    public void ordenarAux(){
        int pos = longitud()-1; 
        T dato;
        if(pos >= 1){
            Lista<T> lista = new ListaDE<T>();
            lista.insertarTodos(this);
            vaciar();
            while(pos > -1){
                dato = lista.acceder(pos);
                ordenar(dato,ini);
                pos-=1;
            }
        }
    }
    
    private void ordenar(T dato, NodoDE<T> fend){
        NodoDE<T> p = new NodoDE<T>(dato);
        if(esVacia()){
            insertar(dato);
        }else{
            NodoDE<T> a = fend.getSuc();
            if(dato.compareTo(fend.getDato()) == 0 || dato.compareTo(fend.getDato()) > 0){
                if(dato.compareTo(a.getDato()) < 0 || a == null){
                    fend.setSuc(p);
                    p.setAnt(fend);
                    p.setSuc(a);
                }
            }else{
                if(fend.getAnt() == null){
                    fend.setAnt(p);
                    p.setSuc(fend);
                    ini = p;
                }else{
                    ordenar(dato,fend.getSuc());
                }
            }
        }
    }
}