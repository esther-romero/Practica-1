package estdat.lineal;

public interface Lista<T>
{
    public boolean esVacia();
    public void insertar(T dato);
    public T eliminar(int pos);
    public T acceder(int pos);
    public void reemplazar(int pos,T dato);
    public void insertar(int pos, T dato);
    public int longitud();
    public boolean buscar(T dato);
    public void vaciar();
    public int indiceDe(T dato);
    public String toString();
    public T eliminar(T dato);
    public boolean equals(Lista<T> lista);
    public void invertir();
    public void insertarTodos(Lista<T> lista);
    public Iterador<T> obtenerIterador();
}
