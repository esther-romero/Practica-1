package estdat.lineal;


public class IteradorCSE<T> implements Iterador<T>
{
    private NodoSE<T> q;
    private NodoSE<T> ini;
    private boolean hay;
    
    public IteradorCSE(NodoSE<T> ini){
        q = ini;
        this.ini = ini;
        hay = !(q==null);
    }
    
    public boolean hayProximo(){
        return hay;
    }
    
    public T       proximo(){
        T dato;
        if(hay){
            dato = q.getDato();
            q = q.getSuc();
            hay = !(q == ini);
        }else{
            dato = null;
        }
        return dato;
    }
}
