package estdat.lineal;


public class ColaPrioridad<T extends Comparable<T>> extends Cola<T>{
    public void encolar(T dato){
        NodoDE<T> p = new NodoDE<T>(dato);
        if(super.esVacia()){
            frente = fin = p;
        }else{
            encolar(dato, fin);
        }
    }
    
    private void encolar(T dato, NodoDE<T> fend){
        NodoDE<T> p = new NodoDE<T>(dato);
        NodoDE<T> a = fend.getSuc();
        if(dato.compareTo(fend.getDato()) == 0 || dato.compareTo(fend.getDato()) > 0){
            fend.setSuc(p);
            p.setAnt(fend);
            p.setSuc(a);
        }else{
            if(fend.getAnt() == null){
                fend.setAnt(p);
                p.setSuc(fend);
                frente = p;
            }else{
                encolar(dato,fend.getAnt());
            }
        }
    }
} 
