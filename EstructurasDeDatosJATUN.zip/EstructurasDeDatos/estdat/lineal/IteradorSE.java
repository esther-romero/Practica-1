package estdat.lineal;

public class IteradorSE<T> implements Iterador<T>
{
    private T           ini;
    private ListaSE<T>  sig;
    private T           q;
    private boolean     hay;         
    
    public IteradorSE(T ini, ListaSE<T>  sig){
        q = ini;
        this.ini = ini;
        this.sig = sig;
        hay = !(q == null);
    }
    
    public boolean hayProximo(){
        return hay;
    }
    
    public T       proximo(){
        T dato;
        if(hay){
            dato = q;
            q = sig.ini;
            sig = sig.sig;
            hay = !(q == null);
        }else{
            dato = null;
        }
        return dato;
    }
}
