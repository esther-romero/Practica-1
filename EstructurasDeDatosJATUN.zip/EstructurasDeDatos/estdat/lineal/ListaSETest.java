package estdat.lineal;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ListaSETest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ListaSETest
{
    /**
     * Default constructor for test class ListaSETest
     */
    public ListaSETest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testVacia(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
    }
    
    @Test
    public void testInsertar(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
    }
    
    @Test
    public void testEliminar(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        dato = lista.eliminar(1);
        assertEquals(1,lista.longitud());
        assertEquals(true,dato.equals("Mundo"));
        dato = lista.eliminar(1);
        assertEquals(1,lista.longitud());
        assertEquals(null,dato);
    }
    
    @Test
    public void testAcceder(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        assertEquals(new String("Hola"),lista.acceder(0));
        assertEquals(new String("Mundo"),lista.acceder(1));
        dato = lista.eliminar(0);
        assertEquals(new String("Mundo"),lista.acceder(0));
        assertEquals(null,lista.acceder(10));
        dato = lista.eliminar(0);
        assertEquals(null,lista.acceder(0));
    }
    
    @Test
    public void testReemplazar(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        lista.reemplazar(0, "Hi");
        lista.reemplazar(5, "lindo");
        assertEquals(new String("Hi"), lista.acceder(0));
    }
    
    @Test
    public void testInsertarPos(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar(2, "Hola");
        assertEquals(true,lista.esVacia());
        lista.insertar(0, "Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar(2, "Hola en pos 2");
        assertEquals(false,lista.esVacia());
        lista.insertar(1, "Hola en pos 1");
        assertEquals(false,lista.esVacia());
        lista.insertar(3, "Hola en pos 3");
        assertEquals(false,lista.esVacia());
        assertEquals(new String("{Mundo, Hola en pos 1}"), lista.toString());
    }
    
    @Test
    public void testLongitud(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
    }
    
    @Test
    public void testBuscar(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
        assertEquals(false,lista.buscar("Mundo"));
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(3 ,lista.longitud());
        assertEquals(true,lista.buscar("Mundo"));
        assertEquals(false,lista.buscar("svknwjr"));
        assertEquals(true,lista.buscar("Hola"));
        assertEquals(false,lista.buscar("svknwjr"));
        assertEquals(true,lista.buscar("!!!"));
        assertEquals(false,lista.buscar("svknwjr"));
    }
    
    @Test
    public void testBuscarDato(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
        assertEquals(false,lista.buscar("Mundo"));
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(3 ,lista.longitud());
        dato = lista.buscarDato("Mundo");
        assertEquals(true,dato.equals("Mundo"));
        dato = lista.buscarDato("svknwjr");
        assertEquals(null,dato);
        dato = lista.buscarDato("Hola");
        assertEquals(true,dato.equals("Hola"));
        dato = lista.buscarDato("svknwjr");
        assertEquals(null,dato);
        dato = lista.buscarDato("!!!");
        assertEquals(true,dato.equals("!!!"));
        dato = lista.buscarDato("svknwjr");
        assertEquals(null,dato);
    }
    
    @Test
    public void testVaciar(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.vaciar();
        assertEquals(true,lista.esVacia());
        assertEquals(0,lista.longitud());
    }
    
    @Test
    public void testIndiceDe(){
        ListaSE<String> lista;
        lista = new ListaSE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(1,lista.indiceDe("Mundo"));
        assertEquals(0,lista.indiceDe("Hola"));
        assertEquals(2,lista.indiceDe("!!!"));
        assertEquals(-1,lista.indiceDe("f"));
        assertEquals(-1,lista.indiceDe("svknwjr"));
    }
    
    @Test
    public void testToString(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        assertEquals(new String("{}"), lista.toString());
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
    }
    
    @Test
    public void testEliminarDato(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        dato = lista.eliminar("Mundo");
        assertEquals(1,lista.longitud());
        assertEquals(true,dato.equals("Mundo"));
        dato = lista.eliminar("Hola");
        assertEquals(0,lista.longitud());
        assertEquals(true,dato.equals("Hola"));
        dato = lista.eliminar("qbcjiuqb");
        assertEquals(null,dato);
    }
    
    @Test
    public void testEquals(){
        ListaSE<String> lista, lista1;
        String dato;
        lista = new ListaSE<String>();
        lista1 = new ListaSE<String>();
        assertEquals(true, lista.equals(lista1));
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(false, lista.equals(lista1));
        lista1.insertar("Hola");
        lista1.insertar("Mundo");
        lista1.insertar("Cruel");
        assertEquals(true, lista.equals(lista1));
        lista1.insertar("!!!");
        assertEquals(false, lista.equals(lista1));
    }
    
    @Test
    public void testInvertir(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        assertEquals(new String("{}"), lista.toString());
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
        lista.invertir();
        assertEquals(new String("{Cruel, Mundo, Hola}"), lista.toString());
    }
    
    @Test
    public void testInsertarTodos(){
        ListaSE<String> lista, lista1;
        String dato;
        lista = new ListaSE<String>();
        lista1 = new ListaSE<String>();
        assertEquals(true, lista.equals(lista1));
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
        lista1.insertar("!!!");
        lista1.insertar("Estamos");
        lista1.insertar("en 2020");
        lista.insertarTodos(lista1);
        assertEquals(new String("{Hola, Mundo, Cruel, !!!, Estamos, en 2020}"), lista.toString());
    }
    
    @Test
    public void testIterador(){
        ListaSE<String> lista;
        String dato;
        lista = new ListaSE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        Iterador<String> ite;
        ite = lista.obtenerIterador();
        while(ite.hayProximo()){
            System.out.println(ite.proximo());
        }
    }
}
