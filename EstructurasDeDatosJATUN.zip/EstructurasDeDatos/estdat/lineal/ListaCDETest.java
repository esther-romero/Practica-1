package estdat.lineal;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ListaCDETest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ListaCDETest
{
    /**
     * Default constructor for test class ListaCDETest
     */
    public ListaCDETest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testVacia(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        assertEquals(true,lista.esVacia());
    }
    
    @Test
    public void testInsertar(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
    }
    
    @Test
    public void testEliminar(){
        ListaCDE<String> lista;
        String dato;
        lista = new ListaCDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        dato = lista.eliminar(1);
        assertEquals(1,lista.longitud());
        assertEquals(true,dato.equals("Mundo"));
        dato = lista.eliminar(10);
        assertEquals(0,lista.longitud());
        assertEquals(true,dato.equals("Hola"));
        dato = lista.eliminar(1);
        assertEquals(null,dato);
    }
    
    @Test
    public void testAcceder(){
        ListaCDE<String> lista;
        String dato;
        lista = new ListaCDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        assertEquals(new String("Hola"),lista.acceder(0));
        assertEquals(new String("Mundo"),lista.acceder(1));
        dato = lista.eliminar(0);
        assertEquals(new String("Mundo"),lista.acceder(0));
        assertEquals(new String("Mundo"),lista.acceder(10));
        dato = lista.eliminar(0);
        assertEquals(null,lista.acceder(0));
    }
    
    @Test
    public void testReemplazar(){
        ListaCDE<String> lista;
        String dato;
        lista = new ListaCDE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        lista.reemplazar(0, "Hi");
        lista.reemplazar(5, "lindo");
        assertEquals(new String("Hi"), lista.acceder(0));
        assertEquals(new String("lindo"), lista.acceder(5));
    }
    
    @Test
    public void testInsertarPos(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        lista.insertar(3,"Hola");
        assertEquals(new String("{Hola}"),lista.toString());
        lista.insertar(0,"Mundo");
        assertEquals(new String("{Mundo, Hola}"),lista.toString());
        lista.insertar(1,"Cruel");
        assertEquals(new String("{Mundo, Cruel, Hola}"),lista.toString());
        lista.insertar(10,"Adios");
        assertEquals(new String("{Mundo, Adios, Cruel, Hola}"),lista.toString());
        assertEquals(false,lista.esVacia());
        assertEquals(4,lista.longitud());
    }
    
    @Test
    public void testLongitud(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
    }
    
    @Test
    public void testBuscar(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        assertEquals(true,lista.esVacia());
        assertEquals(false,lista.buscar("Mundo"));
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(3 ,lista.longitud());
        assertEquals(true,lista.buscar("Mundo"));
        assertEquals(false,lista.buscar("svknwjr"));
        assertEquals(true,lista.buscar("Hola"));
        assertEquals(false,lista.buscar("svknwjr"));
        assertEquals(true,lista.buscar("!!!"));
        assertEquals(false,lista.buscar("svknwjr"));
    }
    
    @Test
    public void testVaciar(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("Cruel");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(4,lista.longitud());
        lista.vaciar();
        assertEquals(true,lista.esVacia());
        assertEquals(0,lista.longitud());
    }
    
    @Test
    public void testIndiceDe(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(1,lista.indiceDe("Mundo"));
        assertEquals(0,lista.indiceDe("Hola"));
        assertEquals(2,lista.indiceDe("!!!"));
        assertEquals(-1,lista.indiceDe("f"));
        assertEquals(-1,lista.indiceDe("svknwjr"));
    }
    
    @Test
    public void testToString(){
        ListaCDE<String> lista;
        String dato;
        lista = new ListaCDE<String>();
        assertEquals(new String("{}"), lista.toString());
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
    }
    
    @Test
    public void testEliminarDato(){
        ListaCDE<String> lista;
        String dato;
        lista = new ListaCDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        dato = lista.eliminar("Mundo");
        assertEquals(true,dato.equals("Mundo"));
        assertEquals(3,lista.longitud());
        dato = lista.eliminar("!!!");
        assertEquals(true,dato.equals("!!!"));
        assertEquals(2,lista.longitud());
        dato = lista.eliminar("gg");
        assertEquals(null,dato);
        assertEquals(2,lista.longitud());
        dato = lista.eliminar("Cruel");
        assertEquals(true,dato.equals("Cruel"));
        assertEquals(1,lista.longitud());
        dato = lista.eliminar("Hola");
        assertEquals(true,dato.equals("Hola"));
        assertEquals(0,lista.longitud());
        assertEquals(true,lista.esVacia());
        dato = lista.eliminar("efe");
        assertEquals(null,dato);
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        dato = lista.eliminar("Hola");
        assertEquals(true,dato.equals("Hola"));
        assertEquals(3,lista.longitud());
        dato = lista.eliminar("efe");
        assertEquals(null,dato);
        dato = lista.eliminar("Mundo");
        assertEquals(true,dato.equals("Mundo"));
        assertEquals(2,lista.longitud());
        dato = lista.eliminar("Cruel");
        assertEquals(true,dato.equals("Cruel"));
        assertEquals(1,lista.longitud());
        dato = lista.eliminar("!!!");
        assertEquals(true,dato.equals("!!!"));
        assertEquals(true,lista.esVacia());
        dato = lista.eliminar("damm");
        assertEquals(null,dato);
    }
    
    @Test
    public void testEquals(){
        ListaCDE<String> lista, lista1;
        String dato;
        lista = new ListaCDE<String>();
        lista1 = new ListaCDE<String>();
        assertEquals(true, lista.equals(lista1));
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(false, lista.equals(lista1));
        lista1.insertar("Hola");
        lista1.insertar("Mundo");
        lista1.insertar("Cruel");
        assertEquals(true, lista.equals(lista1));
        lista1.insertar("!!!");
        assertEquals(false, lista.equals(lista1));
    }
    
    @Test
    public void testInvertir(){
        ListaCDE<String> lista;
        String dato;
        lista = new ListaCDE<String>();
        assertEquals(new String("{}"), lista.toString());
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
        lista.invertir();
        assertEquals(new String("{Cruel, Mundo, Hola}"), lista.toString());
    }
    
    @Test
    public void testInsertarTodos(){
        ListaCDE<String> lista, lista1;
        String dato;
        lista = new ListaCDE<String>();
        lista1 = new ListaCDE<String>();
        assertEquals(true, lista.equals(lista1));
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
        lista1.insertar("!!!");
        lista1.insertar("Estamos");
        lista1.insertar("en 2020");
        lista.insertarTodos(lista1);
        assertEquals(new String("{Hola, Mundo, Cruel, !!!, Estamos, en 2020}"), lista.toString());
    }
    
    @Test
    public void testIterador(){
        ListaCDE<String> lista, lista1;
        String dato;
        lista = new ListaCDE<String>();
        lista1 = new ListaCDE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        Iterador<String> ite;
        ite = lista.obtenerIterador();
        while(ite.hayProximo()){
            System.out.println(ite.proximo());
        }
    }
    
    @Test
    public void testPalindromo(){
        ListaCDE<String> lista;
        lista = new ListaCDE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("oso");
        assertEquals(false, lista.esPalindromo());
        lista.vaciar();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        lista.insertar("Cruel");
        lista.insertar("Mundo");
        lista.insertar("Hola");
        assertEquals(true, lista.esPalindromo());
        lista.insertar(3, "oso");
        assertEquals(true, lista.esPalindromo());
    }
}
