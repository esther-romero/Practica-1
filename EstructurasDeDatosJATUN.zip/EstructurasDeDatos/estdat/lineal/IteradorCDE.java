package estdat.lineal;

public class IteradorCDE<T> implements Iterador<T>{
    private NodoDE<T> q;
    private NodoDE<T> ini;
    private boolean hay;
    public IteradorCDE(NodoDE<T> ini){
        q = ini;
        this.ini = ini;
        hay = !(q == null);
    }
    
    public boolean hayProximo(){
        return hay;
    }
    
    public T       proximo(){
        T dato;
        if(hay){
            dato = q.getDato();
            q = q.getSuc();
            hay = !(q == ini);
        }else{
            dato = null;
        }
        return dato;
    }
}
