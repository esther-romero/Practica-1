package estdat.lineal;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ListaDETest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ListaDETest
{
    /**
     * Default constructor for test class ListaDETest
     */
    public ListaDETest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testVacia(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        assertEquals(true,lista.esVacia());
    }
    
    @Test
    public void testInsertar(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
    }
    
    @Test
    public void testEliminar(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        dato = lista.eliminar(1);
        assertEquals(true,dato.equals("Mundo"));
        assertEquals(3,lista.longitud());
        dato = lista.eliminar(2);
        assertEquals(true,dato.equals("!!!"));
        assertEquals(2,lista.longitud());
        dato = lista.eliminar(1);
        assertEquals(true,dato.equals("Cruel"));
        assertEquals(1,lista.longitud());
        dato = lista.eliminar(0);
        assertEquals(true,dato.equals("Hola"));
        assertEquals(0,lista.longitud());
        assertEquals(true,lista.esVacia());
        dato = lista.eliminar(0);
        assertEquals(null,dato);
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        dato = lista.eliminar(0);
        assertEquals(true,dato.equals("Hola"));
        assertEquals(3,lista.longitud());
        dato = lista.eliminar(0);
        assertEquals(true,dato.equals("Mundo"));
        assertEquals(2,lista.longitud());
        dato = lista.eliminar(0);
        assertEquals(true,dato.equals("Cruel"));
        assertEquals(1,lista.longitud());
        dato = lista.eliminar(0);
        assertEquals(true,dato.equals("!!!"));
        assertEquals(true,lista.esVacia());
        dato = lista.eliminar(0);
        assertEquals(null,dato);
    }
    
    @Test
    public void testAcceder(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        assertEquals(new String("Hola"),lista.acceder(0));
        assertEquals(new String("Mundo"),lista.acceder(1));
        assertEquals(new String("Cruel"),lista.acceder(2));
        assertEquals(new String("!!!"),lista.acceder(3));
        dato = lista.eliminar(0);
        assertEquals(new String("Mundo"),lista.acceder(0));
        assertEquals(null,lista.acceder(10));
        dato = lista.eliminar(0);
        assertEquals(new String("Cruel"),lista.acceder(0));
        dato = lista.eliminar(0);
        assertEquals(new String("!!!"),lista.acceder(0));
        dato = lista.eliminar(0);
        assertEquals(null,lista.acceder(0));
        assertEquals(null,lista.acceder(20));
    }
    
    @Test
    public void testReemplazar(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        lista.reemplazar(0, "Hi");
        lista.reemplazar(5, "lindo");
        assertEquals(new String("Hi"), lista.acceder(0));
    }
    
    @Test
    public void testInsertar1(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        lista.insertar(3,"Hola");
        assertEquals(new String("{}"),lista.toString());
        lista.insertar(0,"Mundo");
        assertEquals(new String("{Mundo}"),lista.toString());
        lista.insertar(1,"Cruel");
        assertEquals(new String("{Mundo, Cruel}"),lista.toString());
        lista.insertar(10,"Adios");
        assertEquals(new String("{Mundo, Cruel}"),lista.toString());
        lista.insertar(2,"Hola");
        assertEquals(new String("{Mundo, Cruel, Hola}"),lista.toString());
        assertEquals(false,lista.esVacia());
        assertEquals(3,lista.longitud());
    }
    
    @Test
    public void testLongitud(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
    }
    
    @Test
    public void testBuscar(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        assertEquals(true,lista.esVacia());
        assertEquals(false,lista.buscar("Mundo"));
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(3 ,lista.longitud());
        assertEquals(true,lista.buscar("Mundo"));
        assertEquals(true,lista.buscar("Hola"));
        assertEquals(true,lista.buscar("!!!"));
        assertEquals(false,lista.buscar("svknwjr"));
    }
    
    @Test
    public void testVaciar(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("Cruel");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(4,lista.longitud());
        lista.vaciar();
        assertEquals(true,lista.esVacia());
        assertEquals(0,lista.longitud());
    }
    
    @Test
    public void testIndiceDe(){
        ListaDE<String> lista;
        lista = new ListaDE<String>();
        assertEquals(true,lista.esVacia());
        lista.insertar("Hola");
        assertEquals(false,lista.esVacia());
        lista.insertar("Mundo");
        assertEquals(false,lista.esVacia());
        lista.insertar("!!!");
        assertEquals(false,lista.esVacia());
        assertEquals(1,lista.indiceDe("Mundo"));
        assertEquals(0,lista.indiceDe("Hola"));
        assertEquals(2,lista.indiceDe("!!!"));
        assertEquals(-1,lista.indiceDe("f"));
        assertEquals(-1,lista.indiceDe("svknwjr"));
    }
    
    @Test
    public void testToString(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        assertEquals(new String("{}"), lista.toString());
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
    }
    
    @Test
    public void testEliminarDato(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        assertEquals(0,lista.longitud());
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        dato = lista.eliminar("Mundo");
        assertEquals(true,dato.equals("Mundo"));
        assertEquals(3,lista.longitud());
        dato = lista.eliminar("!!!");
        assertEquals(true,dato.equals("!!!"));
        assertEquals(2,lista.longitud());
        dato = lista.eliminar("gg");
        assertEquals(null,dato);
        dato = lista.eliminar("Cruel");
        assertEquals(true,dato.equals("Cruel"));
        assertEquals(1,lista.longitud());
        dato = lista.eliminar("Hola");
        assertEquals(true,dato.equals("Hola"));
        assertEquals(0,lista.longitud());
        assertEquals(true,lista.esVacia());
        dato = lista.eliminar("efe");
        assertEquals(null,dato);
        lista.insertar("Hola");
        assertEquals(1,lista.longitud());
        lista.insertar("Mundo");
        assertEquals(2,lista.longitud());
        lista.insertar("Cruel");
        assertEquals(3,lista.longitud());
        lista.insertar("!!!");
        assertEquals(4,lista.longitud());
        dato = lista.eliminar("Hola");
        assertEquals(true,dato.equals("Hola"));
        assertEquals(3,lista.longitud());
        dato = lista.eliminar("efe");
        assertEquals(null,dato);
        dato = lista.eliminar("Mundo");
        assertEquals(true,dato.equals("Mundo"));
        assertEquals(2,lista.longitud());
        dato = lista.eliminar("Cruel");
        assertEquals(true,dato.equals("Cruel"));
        assertEquals(1,lista.longitud());
        dato = lista.eliminar("!!!");
        assertEquals(true,dato.equals("!!!"));
        assertEquals(true,lista.esVacia());
        dato = lista.eliminar("damm");
        assertEquals(null,dato);
    }
    
    @Test
    public void testEquals(){
        ListaDE<String> lista, lista1;
        String dato;
        lista = new ListaDE<String>();
        lista1 = new ListaDE<String>();
        assertEquals(true, lista.equals(lista1));
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(false, lista.equals(lista1));
        lista1.insertar("Hola");
        lista1.insertar("Mundo");
        lista1.insertar("Cruel");
        assertEquals(true, lista.equals(lista1));
        lista1.insertar("!!!");
        assertEquals(false, lista.equals(lista1));
    }
    
    @Test
    public void testInvertir(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        assertEquals(new String("{}"), lista.toString());
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
        lista.invertir();
        assertEquals(new String("{Cruel, Mundo, Hola}"), lista.toString());
    }
    
    @Test
    public void testInsertarTodos(){
        ListaDE<String> lista, lista1;
        String dato;
        lista = new ListaDE<String>();
        lista1 = new ListaDE<String>();
        assertEquals(true, lista.equals(lista1));
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        assertEquals(new String("{Hola, Mundo, Cruel}"), lista.toString());
        lista1.insertar("!!!");
        lista1.insertar("Estamos");
        lista1.insertar("en 2020");
        lista.insertarTodos(lista1);
        assertEquals(new String("{Hola, Mundo, Cruel, !!!, Estamos, en 2020}"), lista.toString());

    }
    
    @Test
    public void testIterador(){
        ListaDE<String> lista;
        String dato;
        lista = new ListaDE<String>();
        lista.insertar("Hola");
        lista.insertar("Mundo");
        lista.insertar("Cruel");
        Iterador<String> ite;
        ite = lista.obtenerIterador();
        while(ite.hayProximo()){
            System.out.println(ite.proximo());
        }
    }
    
    @Test
    public void testOrdenar(){
        ListaDE<Integer> lista;
        lista = new ListaDE<Integer>();
        assertEquals(true,lista.esVacia());
        lista.insertar(7);
        lista.insertar(5);
        lista.insertar(3);
        lista.insertar(1);
        lista.insertar(9);
        lista.insertar(8);
        assertEquals(false,lista.esVacia());
        lista.ordenarAux();
        assertEquals(new String("{1, 3, 5, 7, 8, 9}"), lista.toString());
    }
}
