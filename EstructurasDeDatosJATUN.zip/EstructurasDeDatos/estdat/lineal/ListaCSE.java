package estdat.lineal;
import java.util.*;

public class ListaCSE<T> implements Lista<T> 
{
    private NodoSE<T>ini;
    
    public ListaCSE (){
        ini = null;
    }
    
    public boolean esVacia(){
        return ini == null;
    }
    
    public void insertar(T dato){
        NodoSE<T> p = new NodoSE<T> (dato);
        if(esVacia()){
            ini = p;
            ini.setSuc(ini);
        }else{
            insertar(ini, dato);
        }
    }
    
    private void insertar(NodoSE<T> p, T dato){
        NodoSE<T> q = new NodoSE<T>(dato);
        if(p.getSuc() == ini){ 
            p.setSuc(q);
            q.setSuc(ini);
        }else{
            insertar(p.getSuc(), dato);
        }
    }
    
    public T eliminar(int pos){
        T datoElim = null;
        NodoSE<T> q,s,r;
        if(!esVacia()){
            q = buscarPos(ini,pos);
            datoElim = q.getDato();
            s = q.getSuc();
            if(longitud() > 1 && pos != 0){
                r = buscarPos(ini,pos-1);
                r.setSuc(s);
            }else{
                if(q == s)
                    ini = null;
                else{
                    r = buscarPos(ini,longitud()-1);
                    ini = s;
                    r.setSuc(ini);
                }
            }
        }
        return datoElim;
    }
    
    private NodoSE<T> buscarPos(NodoSE<T> q, int pos){
        NodoSE<T> elNodo;
        if(pos == 0){
            elNodo = q;
        }else{
            elNodo = buscarPos(q.getSuc(), pos-1);
        }
        return elNodo;
    }
    
    public T acceder(int pos){
        NodoSE<T> q;
        T elDato = null;
        if(!esVacia()){
            q = buscarPos(ini, pos);
            elDato = q.getDato();
        }
        return elDato;
    }
    
    public void reemplazar(int pos,T dato){
        NodoSE<T> q;
        if(!esVacia()){
            q = buscarPos(ini,pos);
            q.setDato(dato);
        }
    }
    
    public void insertar(int pos, T dato){
        NodoSE<T> p = new NodoSE<T>(dato);
        NodoSE<T> q, r; 
        if(esVacia()){
            ini = p;
            ini.setSuc(ini);
        }else{
            q = buscarPos(ini,pos);
            if(longitud() > 1){
                r = buscarPos(ini,pos-1);
                if(ini == q){
                    ini = p;
                    ini.setSuc(q);
                }else{
                    r.setSuc(p);
                    p.setSuc(q);
                }
            }else{
                ini = p;
                ini.setSuc(q);
                q.setSuc(ini);
            }
        }
    }
    
    public int longitud(){
        int longitud = 0;
        if(!esVacia()){
            longitud = contar(ini);
        }
        return longitud;
    }
    
    private int contar(NodoSE<T> q){
        int contador;
        if(q.getSuc() == ini){
            contador = 1;
        }else{
            contador = 1+contar(q.getSuc());
        }
        return contador;
    }
    
    public boolean buscar(T dato){
        boolean existe = false;
        if(!esVacia()){
            existe = buscar(longitud()-1, dato);
        }
        return existe;
    }
    
    private boolean buscar(int pos, T dato){
        boolean existe = false;
        NodoSE<T> q;
        if(pos >= 0){
            q = buscarPos(ini, pos);
            if(q.getDato().equals(dato)){
                existe = true;
            }else{
                existe = buscar(pos-1, dato);
            }
        }
        return existe;
    }
    
    public void vaciar(){
        if(!esVacia()){
            ini = null;
        }
    }
    
    public int indiceDe(T dato){
        int res =  -1;
        if(!esVacia()){
            res = indiceDe(longitud()-1, dato);
        }
        return res;
    }
    
    private int indiceDe(int pos, T dato){
        int iesima = -1;
        NodoSE<T> q;
        if(pos >= 0){
            q = buscarPos(ini, pos);
            if(q.getDato().equals(dato)){
                iesima = pos;
            }else{
                iesima = indiceDe(pos-1, dato);
            }
        }
        return iesima;
    }
    
    public String toString(){
        String datos;
        if(esVacia())
            datos = "{}";
        else
            datos = "{" + toString(ini) + "}";
        return datos;
    }
    
    private String toString(NodoSE<T> q){
        String datos;
        if(q.getSuc() == ini)
            datos = q.getDato() + "";
        else
            datos = q.getDato() + ", " + toString(q.getSuc());
        return datos;
    }
    
    public T eliminar(T dato){
        T res = null;
        int dt = indiceDe(dato);
        if(dt != -1){
            res = eliminar(dt);
        }
        return res;
    }
    
    public boolean equals(Lista<T> lista){
        boolean igual;
        if(esVacia())
            igual = lista.esVacia();
        else
            igual = equals(lista, 0, lista.longitud(), ini);
        return igual;
    }
    
    private boolean equals(Lista<T> lista, int i, int tam, NodoSE<T> q){
        boolean igual;
        if(i < tam){
            if(q.getSuc() == ini)
                igual = lista.acceder(i).equals(q.getDato()) && !(i+1 < tam);
            else
                igual = lista.acceder(i).equals(q.getDato()) && 
                equals(lista, i+1, tam, q.getSuc());
        }else{
            igual = false;
        }
        return igual;
    }
    
    public void invertir(){
        if(longitud()>1){
            T dato = eliminar(0);
            invertir();
            insertar(dato);
        }
    }
    
    public void invertirTrucho(){
        if(!esVacia()){
            ArrayList<T> ar = new ArrayList<>();
            ar.add(ini.getDato());
            NodoSE<T> p = ini.getSuc();
            while(p!=ini){
                ar.add(p.getDato());
                p = p.getSuc();
            }
            ini=null;
            for(int i = ar.size()-1;i>-1;i--){
                insertar(ar.get(i));
            }
        }
    }
    
    public void insertarTodos(Lista<T> lista){
        insertarTodos(lista, 0, lista.longitud());
    }
    
    private void insertarTodos(Lista<T> lista, int i, int tam){
        if(i < tam){
            insertar(lista.acceder(i));
            insertarTodos(lista, i+1, tam);
        }   
    }
    
    public Iterador<T> obtenerIterador(){
        return new IteradorCSE<T>(ini);
    }
}
