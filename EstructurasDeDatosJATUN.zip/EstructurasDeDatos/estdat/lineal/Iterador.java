package estdat.lineal;


/**
 * Write a description of interface Iterador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Iterador<T>{
    public boolean hayProximo();
    public T       proximo();
}
