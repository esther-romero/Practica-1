package estdat.lineal;


/**
 * Write a description of class Bicola here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bicola<T> extends Cola<T>
{
    //meter
    public void aumentarFrente(T dato){
        NodoDE<T> p = new NodoDE<T>(dato);
        if(esVacia()){
            frente = fin = p;
        }else{
            frente.setAnt(p);
            p.setSuc(frente);
            frente = p;
        }
    }
    
    public void aumentarFinal(T dato){
        super.encolar(dato);
    }
    //salir
    public T removerFinal(){
        T elDato;
        if(esVacia()){
            elDato = null;
        }else{
            elDato = fin.getDato();
            fin = fin.getAnt();
            if(fin == null){
                frente = null;
            }else{
                fin.setSuc(null);
            }
        }
        return elDato;
    }
    
    public T removerFrente(){
        return super.decolar();
    }
    
    public T verFrente(){
        return super.ver();
    }
    
    public T verFinal(){
        T elDato;
        if(esVacia()){
            elDato = null;
        }else{
            elDato = fin.getDato();
        }
        return elDato;
    }
}
