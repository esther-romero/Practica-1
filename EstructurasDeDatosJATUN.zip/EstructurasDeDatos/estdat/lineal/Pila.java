package estdat.lineal;


/**
 * Write a description of class Pila here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pila<T>{
    private T tope;
    private Pila<T> base;
    
    public Pila(){
        tope = null;
        base = null;
    }
    
    public boolean esVacia(){
        return tope==null;
    }
    
    public void push(T dato){
        Pila<T> aux;
        if(esVacia()){
            tope = dato;
            base = new Pila<T>();
        }else{
            aux = new Pila<T>();
            aux.tope = tope;
            aux.base = base;
            base = aux;
            tope = dato;
        }
    }
    
    public T pop(){
       T elDato;
       if(esVacia()){
           elDato = null;
       }else{
           elDato = tope;
           tope = base.tope;
           base = base.base;
       }
       return elDato;
    }
    
    public T top(){
       return tope;
    }
}
