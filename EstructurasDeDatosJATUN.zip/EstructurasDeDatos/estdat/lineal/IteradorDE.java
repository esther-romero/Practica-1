package estdat.lineal;


public class IteradorDE<T> implements Iterador<T>{
    private NodoDE<T> q;
    private NodoDE<T> ini;
    private boolean hay;
    public IteradorDE(NodoDE<T> ini){
        q = ini;
        this.ini = ini;
        hay = !(q == null);
    }
    
    public boolean hayProximo(){
        return hay;
    }
    
    public T       proximo(){
        T dato;
        if(hay){
            dato = q.getDato();
            q = q.getSuc();
            hay = !(q == null);
        }else{
            dato = null;
        }
        return dato;
    }
}
