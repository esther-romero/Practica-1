package estdat.lineal;

public class ListaSE<T> implements Lista<T> 
{
    protected T           ini;
    protected ListaSE<T>  sig;
    public ListaSE(){
        ini = null;
        sig = null;
    }
    
    public boolean esVacia(){
        return ini == null;
    }
        
    public void insertar(T dato){
        if(esVacia()){
            ini = dato;
            sig = new ListaSE<T>();
        }else{
            sig.insertar(dato);
        }
    }
    
    public T eliminar(int pos){
        T datoElim;
        if(esVacia()){
            datoElim =  null;
        }else{
            if(pos == 0){
                datoElim = ini;
                ini = sig.ini;
                sig = sig.sig;
            }else{
                datoElim = sig.eliminar(pos -1);
            }
        }
        return datoElim;
    }
    
    public T acceder(int pos){
        T elDato;
        if(esVacia()){
            elDato = null;
        }else{
            if(pos == 0){
                elDato = ini;
            }else{
                elDato = sig.acceder(pos-1);
            }
        }
        return elDato;
    }
    
    public void reemplazar(int pos,T dato){
        if(!esVacia()){
            if(pos == 0){
                ini = dato;
            }else{
                sig.reemplazar(pos-1,dato);
            }
        }
    }
    
    public void insertar(int pos, T dato){
        if(esVacia()){
            if(pos == 0){
                ini = dato;
                sig = new ListaSE<T>();
            }
        }else{
            if(pos == 0){
                sig.insertar(0,ini);
                ini = dato;
            }else{
                sig.insertar(pos-1, dato);
            }
        }
    }
    
    public int longitud(){
        int longitud;
        if(esVacia()){
            longitud = 0;
        }else{
            longitud = 1 + sig.longitud();
        }
        return longitud;
    }
    
    public boolean buscar(T dato){
        boolean existe = false;
        if(!esVacia()){
            if(ini.equals(dato)){
                existe = true;
            }else{
                existe = sig.buscar(dato);
            }
        }
        return existe;
    }
    
    public T buscarDato(T dato){
        T dat = null;
        if(!esVacia()){
            if(ini.equals(dato)){
                dat = ini;
            }else{
                dat = sig.buscarDato(dato);
            }
        }
        return dat;
    }
    
    public void vaciar(){
        if(!esVacia()){
            ini = null;
            sig = null;
        }
    }
    
    public int indiceDe(T dato){
        int iesima = -1;
        if(!esVacia()){
            if(buscar(dato) == true){
                if(ini.equals(dato)){
                    iesima = 0;
                }else{
                    iesima = 1 + sig.indiceDe(dato);
                }
            }
        }
        return iesima;
    }
    
    public String toString(){
        String datos;
        if(esVacia())
            datos = "{}";
        else
            datos = "{" + toStringDatos() + "}";
        return datos;
    }
    
    private String toStringDatos(){
        String datos;
        if(sig.esVacia())
            datos = ini + "";
        else
            datos = ini + ", " + sig.toStringDatos();
        return datos;
    }
    
    public T eliminar(T dato){
        T res = null;
        int dt = indiceDe(dato);
        if(dt != -1){
            res = eliminar(dt);
        }
        return res;
    }
    
    public boolean equals(Lista<T> lista){
        boolean igual;
        if(esVacia())
            igual = lista.esVacia();
        else
            igual = equals(lista, 0, lista.longitud());
        return igual;
    }
    
    private boolean equals(Lista<T> lista, int i, int tam){
        boolean igual;
        if(i < tam){
            if(i+1<tam){
                if(esVacia())
                    igual = false;
                else{
                    if(ini.equals(lista.acceder(i)))
                        igual = sig.equals(lista,i+1,tam);
                    else
                        igual = false;
                }
            }else{
                if(esVacia())
                    igual = false;
                else
                    igual = ini.equals(lista.acceder(i)) && sig.equals(lista, i+1, tam);
            }
        }else{
            igual = esVacia();
        }
        return igual;
    }
    
    public void invertir(){
        if(!esVacia()){
            sig.invertir();
            sig.insertar(ini);
            ini = sig.ini;
            sig = sig.sig;
        }
    }
    
    public void insertarTodos(Lista<T> lista){
        if(esVacia())
            insertarTodos(lista, 0, lista.longitud());
        else
            sig.insertarTodos(lista);
    }
    
    private void insertarTodos(Lista<T> lista, int i, int tam){
        if(i<tam){
            insertar(lista.acceder(i));
            sig.insertarTodos(lista, i+1, tam);
        }
    }
    
    public Iterador<T> obtenerIterador(){
        return new IteradorSE<T>(ini, sig);
    }
}
