
package estdat.nolineal;
import estdat.lineal.*;

/**
 * Write a description of class ArbolBin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ArbolBin<T>{
    private ArbolBin<T> izq;
    private T           raiz;
    private ArbolBin<T> der;
    
    public ArbolBin(){
        raiz = null;
        izq = der = null;
    }
    
    public boolean esVacia(){
        return raiz == null;
    }
    
    public void vaciar(){
        if(!esVacia()){
            raiz = null;
            izq = der = null;
        }
    }
    
    private boolean esHoja(){
        return raiz!=null && ((izq == null && der == null ) || (izq.esVacia()) && der.esVacia());    
    }
    
    public T getRaiz(){
        return raiz;
    }
    
    public ArbolBin<T> getIzq(){
        return izq;
    }
    
    public ArbolBin<T> getDer(){
        return der;
    }
    //plantilla profundidad
    public void dfs(){
        if(!esVacia()){
            izq.dfs();
            //operacion
            izq.dfs();
        }
    }
    //plantilla amplitud
    public void bfs(){
        Cola<ArbolBin<T>> cola = new  Cola<>();
        cola.encolar(this);
        ArbolBin<T> x;
        while(!cola.esVacia()){
            x = cola.decolar();
            if(!x.esVacia()){
                //operacion
                cola.encolar(x.izq);
                cola.encolar(x.der);
            }
        }
    }
    
    public boolean buscar(T dato){
        boolean res = false;
        if(!esVacia()){
            if(raiz.equals(dato)){
                res = true;
            }else{
                res = izq.buscar(dato);
                if(res == false){
                    res = der.buscar(dato);
                }
            }
        }
        return res;
    }
    //poda a altura, no a nivel
    public void podar(int n){
        if(!esVacia()){
            if(n == 1){
                izq = new ArbolBin();
                der = new ArbolBin();
            }else{
                izq.podar(n-1);
                der.podar(n-1);
            }
        }       
    }
    
    public Lista<T> hojas(){
        Lista<T> datos;
        datos = new ListaSE<T>();
        if(!esVacia()){
            if(esHoja()){
                datos.insertar(raiz);
            }
            else{
                datos.insertarTodos(izq.hojas());
                datos.insertarTodos(der.hojas());
            }
        }
        return datos;
    }
    
    public boolean bordeIgual(ArbolBin<T> a)
    {
        return hojas().equals(a.hojas());
    }
    
    public boolean insertar(T dato, Lista<T> ruta){
        boolean sePudo;
        T r1;
        sePudo = false;
        if(ruta.esVacia()){
            if(esVacia()){
                sePudo = true;
                raiz = dato;
                izq = new ArbolBin<T>();
                der = new ArbolBin<T>();
            }
        }else{
            if(!esVacia()){
                r1 = ruta.acceder(0);
                if(r1.equals(raiz)){
                    ruta.eliminar(0);
                    sePudo = izq.insertar(dato, ruta);
                    if(!sePudo)
                        sePudo = der.insertar(dato, ruta);
                    ruta.insertar(0, r1);
                }
            }
        }    
        return sePudo;
    }
    
    public void insertar(T dato){
        Cola<ArbolBin<T>> cola;
        cola = new Cola<ArbolBin<T>>();
        cola.encolar(this);
        insertar(dato, cola);
    }
    
    private void insertar(T dato, Cola<ArbolBin<T>> cola){
        ArbolBin<T> arb;
        arb = cola.decolar();
        if(arb.esVacia()){
            arb.raiz = dato;
            arb.izq = new ArbolBin<T>();
            arb.der = new ArbolBin<T>();
        }else{
            cola.encolar(arb.izq);
            cola.encolar(arb.der);
            insertar(dato, cola);
        }
    }
    
    public void insertarDerecha(T dato){
        Cola<ArbolBin<T>> cola;
        cola = new Cola<ArbolBin<T>>();
        cola.encolar(this);
        insertarDerecha(dato, cola);
    }
    
    private void insertarDerecha(T dato, Cola<ArbolBin<T>> cola){
        ArbolBin<T> arb;
        arb = cola.decolar();
        if(arb.esVacia()){
            arb.raiz = dato;
            arb.izq = new ArbolBin<T>();
            arb.der = new ArbolBin<T>();
        }else{
            cola.encolar(arb.der);
            insertarDerecha(dato, cola);
        }
    }
    
    public int altura(){
        return altura(this);
    }
    
    private int altura(ArbolBin<T> act){
        int res;
        if(act != null){
            if(act.esVacia())
                res = 0;
            else{
                res = 1 + Math.max(altura(act.getIzq()), altura(act.getDer()));
            }
        }else
            res = 0;
        return res;
    }
    //izq, raiz, der
    public Lista<T> inOrden(){
        Lista<T> datos;
        datos = new ListaSE<T>();
        if(!esVacia()){
            datos.insertarTodos(izq.inOrden());
            datos.insertar(raiz);
            datos.insertarTodos(der.inOrden());
        }
        return datos;
    }
    
    public Lista<T> preOrden(){
        Lista<T> datos;
        datos = new ListaSE<T>();
        if(!esVacia()){
            datos.insertar(raiz);
            datos.insertarTodos(izq.preOrden());
            datos.insertarTodos(der.preOrden());
        }
        return datos;
    }
    
    public Lista<T> posOrden(){
        Lista<T> datos;
        datos = new ListaSE<T>();
        if(!esVacia()){
            datos.insertarTodos(izq.posOrden());
            datos.insertarTodos(der.posOrden());
            datos.insertar(raiz);
        }
        return datos;
    }
    
    public boolean espejoDeSiMismo(){
        boolean res = false;
        res = espejoDeSiMismo(izq,der);
        return res;
    }
    
    private boolean espejoDeSiMismo(ArbolBin<T> a, ArbolBin<T> b){
        boolean res = false;
        if(a.esVacia() && b.esVacia()){
            res = true;
        }else if(!a.esVacia() && b.esVacia() || (a.esVacia() && !b.esVacia())){
            res = false;
        }else if(a.raiz.equals(b.raiz)){
            res = espejoDeSiMismo(a.izq, b.der) && espejoDeSiMismo(a.der, b.izq);
        }
        return res;
    }
    
    public Lista<T> datosNivel(int n){
        Lista<T> l = new ListaSE<T>();
        if(!esVacia()){
            if(n == 0){
                l.insertar(raiz);
            }else{
                l.insertarTodos(izq.datosNivel(n-1));
                l.insertarTodos(der.datosNivel(n-1));
            }
        }
        return l;
    } 
    
    public ArbolBin<T> aplanar(ArbolBin<T> arb){
        Lista<T> lista = arb.preOrden();
        arb.vaciar(); 
        arb = aplanar(arb, lista);
        return arb;
    } 
    
    private ArbolBin<T> aplanar(ArbolBin<T> arbolito, Lista<T> lista){
        ArbolBin<T> arboli = arbolito;
        if(!lista.esVacia()){
            T dato = lista.eliminar(0);
            arbolito.insertarDerecha(dato);
            arboli = aplanar(arbolito,lista);
        }
        return arboli;
    }
    
    public int distancia(T dato, T dato1){
        int res = -1;
        Cola<ArbolBin<T>> cola = new Cola<ArbolBin<T>>();
        cola.encolar(this);
        if(!esVacia()){
            if(buscar(dato) && buscar(dato1)){
                if(dato1 == dato)
                    res = 0;
                else
                    res = distancia(dato, dato1, cola);
            }
        }
        return res;
    }
    
    private int distancia(T dato,T dato1, Cola<ArbolBin<T>> cola){
        int res = 0;
        ArbolBin<T> arbolito;
        if(!cola.esVacia()){
            arbolito = cola.decolar();
            if(!arbolito.izq.esVacia())
                cola.encolar(arbolito.izq);
            if(!arbolito.der.esVacia())
                cola.encolar(arbolito.der);
            if(arbolito.getRaiz() == dato){
                if(dato == dato1)
                    res += 0;
                else
                    res = 1 + distancia(dato1, dato1, cola);
            }else{
                if(dato == dato1)
                    res = 1 + distancia(dato1, dato1, cola);
                else
                    res = distancia(dato, dato1, cola);
            }
        }else{
            res = 0;
        }
        return res;
    }
}