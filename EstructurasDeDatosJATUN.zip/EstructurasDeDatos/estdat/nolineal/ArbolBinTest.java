

package estdat.nolineal;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ArbolBinTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ArbolBinTest
{
    /**
     * Default constructor for test class ArbolBinTest
     */
    public ArbolBinTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testEspejo(){
        ArbolBin<Character> a = new ArbolBin();
        a.insertar('d');
        a.insertar('b');
        a.insertar('b');
        a.insertar('a');
        a.insertar('c');
        a.insertar('c');
        a.insertar('a');
        
        assertEquals(true, a.espejoDeSiMismo());
    }
    
    @Test
    public void testBuscar(){
        ArbolBin<Integer> a = new ArbolBin();
        a.insertar(1);
        a.insertar(2);
        a.insertar(3);
        a.insertar(4);
        a.insertar(5);
        a.insertar(6);
        a.insertar(7);
        a.insertar(8);
        a.insertar(9);
        
        assertEquals(true, a.buscar(new Integer(6)));
        assertEquals(false, a.buscar(new Integer(100)));
    }
}
