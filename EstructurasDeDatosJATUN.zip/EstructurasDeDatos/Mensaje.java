import java.util.Calendar;
import java.util.GregorianCalendar;

public class Mensaje{
    private int remitente;
    private int destinatario;
    private boolean enviado;
    private boolean leido;
    private String mensaje;
    private String hora;
    
    public Mensaje(int remitente, int destinatario, String mensaje){
        this.remitente = remitente;
        this.destinatario = destinatario;
        enviado = true;
        leido = false;
        this.mensaje = mensaje;
        hora = horaC();
    }
    
    private String horaC(){
        String hora = "";
        Calendar calendario = new GregorianCalendar();
        int horaA = calendario.get(Calendar.HOUR_OF_DAY);
        int minutos = calendario.get(Calendar.MINUTE);
        int segundos = calendario.get(Calendar.SECOND);
        hora = horaA + ":" + minutos + ":" + segundos;
        return hora;
    }
    
    protected void cambiar(){
        leido = true;
    }
    
    public int getRemitente(){
        return remitente;
    }
}
